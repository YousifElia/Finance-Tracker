import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TransactionModal } from "@/components/transaction-modal";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";

export default function Calendar() {
  const [transactionModalOpen, setTransactionModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const startOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
  const endOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0);
  
  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/transactions", {
      startDate: startOfMonth.toISOString().split('T')[0],
      endDate: endOfMonth.toISOString().split('T')[0],
    }],
  });

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());

    const days = [];
    const current = new Date(startDate);
    
    while (current <= lastDay || current.getDay() !== 0) {
      days.push(new Date(current));
      current.setDate(current.getDate() + 1);
    }
    
    return days;
  };

  const getTransactionsForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return transactions.filter((t: any) => t.date === dateStr);
  };

  const getDayTotal = (date: Date) => {
    const dayTransactions = getTransactionsForDate(date);
    return dayTransactions.reduce((sum: number, t: any) => {
      return sum + (t.type === "income" ? parseFloat(t.amount) : -parseFloat(t.amount));
    }, 0);
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(newDate.getMonth() - 1);
      } else {
        newDate.setMonth(newDate.getMonth() + 1);
      }
      return newDate;
    });
  };

  const days = getDaysInMonth(currentMonth);
  const selectedDateTransactions = getTransactionsForDate(selectedDate);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Calendar</h2>
          <p className="text-muted-foreground">
            View your spending patterns by day
          </p>
        </div>
        <Button onClick={() => setTransactionModalOpen(true)} className="flex items-center space-x-2">
          <Plus className="h-4 w-4" />
          <span>Add Transaction</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Calendar */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>
                  {currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </CardTitle>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => navigateMonth('prev')}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => navigateMonth('next')}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 mb-4">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="p-2 text-center text-sm font-medium text-muted-foreground">
                    {day}
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-7 gap-1">
                {days.map((day, index) => {
                  const isCurrentMonth = day.getMonth() === currentMonth.getMonth();
                  const isToday = day.toDateString() === new Date().toDateString();
                  const isSelected = day.toDateString() === selectedDate.toDateString();
                  const dayTransactions = getTransactionsForDate(day);
                  const dayTotal = getDayTotal(day);
                  
                  return (
                    <button
                      key={index}
                      onClick={() => setSelectedDate(day)}
                      className={`p-2 min-h-[80px] text-left border rounded-lg transition-colors ${
                        isSelected 
                          ? 'border-primary bg-primary/5' 
                          : 'border-border hover:bg-muted/50'
                      } ${!isCurrentMonth ? 'opacity-40' : ''}`}
                    >
                      <div className={`text-sm font-medium ${
                        isToday ? 'text-primary' : 'text-foreground'
                      }`}>
                        {day.getDate()}
                      </div>
                      
                      {dayTransactions.length > 0 && (
                        <div className="mt-1 space-y-1">
                          {dayTransactions.slice(0, 2).map((transaction: any, i: number) => (
                            <div
                              key={i}
                              className="w-full h-1 rounded-full"
                              style={{ backgroundColor: transaction.category.color }}
                            />
                          ))}
                          {dayTransactions.length > 2 && (
                            <div className="text-xs text-muted-foreground">
                              +{dayTransactions.length - 2} more
                            </div>
                          )}
                          <div className={`text-xs font-medium ${
                            dayTotal >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {dayTotal >= 0 ? '+' : ''}${Math.abs(dayTotal).toLocaleString()}
                          </div>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Day Details */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>
                {selectedDate.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedDateTransactions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No transactions on this day</p>
                  <Button
                    onClick={() => setTransactionModalOpen(true)}
                    variant="outline"
                    size="sm"
                    className="mt-4"
                  >
                    Add Transaction
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-4 border-b border-border">
                    <span className="text-sm font-medium">Day Total</span>
                    <span className={`font-bold ${
                      getDayTotal(selectedDate) >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {getDayTotal(selectedDate) >= 0 ? '+' : ''}${Math.abs(getDayTotal(selectedDate)).toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="space-y-3">
                    {selectedDateTransactions.map((transaction: any) => (
                      <div key={transaction.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div
                            className="w-8 h-8 rounded-lg flex items-center justify-center"
                            style={{
                              backgroundColor: `${transaction.category.color}20`,
                              color: transaction.category.color,
                            }}
                          >
                            <i className={transaction.category.icon} style={{ fontSize: '12px' }} />
                          </div>
                          <div>
                            <p className="text-sm font-medium">
                              {transaction.description || transaction.category.name}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {transaction.category.name}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-sm font-semibold ${
                            transaction.type === "income" ? "text-green-600" : "text-red-600"
                          }`}>
                            {transaction.type === "income" ? "+" : "-"}${parseFloat(transaction.amount).toLocaleString()}
                          </div>
                          <Badge
                            variant="secondary"
                            className={`text-xs ${
                              transaction.type === "income" 
                                ? "bg-green-100 text-green-700" 
                                : "bg-red-100 text-red-700"
                            }`}
                          >
                            {transaction.type}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <TransactionModal
        open={transactionModalOpen}
        onOpenChange={setTransactionModalOpen}
      />
    </div>
  );
}
