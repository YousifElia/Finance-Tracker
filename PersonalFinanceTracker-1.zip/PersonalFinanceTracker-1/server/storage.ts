import {
  users,
  accounts,
  categories,
  transactions,
  investments,
  netWorthSnapshots,
  type User,
  type InsertUser,
  type Account,
  type InsertAccount,
  type Category,
  type InsertCategory,
  type Transaction,
  type InsertTransaction,
  type Investment,
  type InsertInvestment,
  type TransactionWithRelations,
  type NetWorthSnapshot,
  type InsertNetWorthSnapshot,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, gte, lte, sum, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Accounts
  getUserAccounts(userId: number): Promise<Account[]>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccount(id: number, account: Partial<InsertAccount>): Promise<Account | undefined>;
  deleteAccount(id: number): Promise<boolean>;

  // Categories
  getUserCategories(userId: number): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Transactions
  getUserTransactions(userId: number, limit?: number, offset?: number): Promise<TransactionWithRelations[]>;
  getTransactionsByDateRange(userId: number, startDate: string, endDate: string): Promise<TransactionWithRelations[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: number, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: number): Promise<boolean>;

  // Dashboard data
  getDashboardData(userId: number): Promise<{
    totalIncome: string;
    totalExpenses: string;
    netCashFlow: string;
    categorySpending: Array<{ category: string; amount: string; color: string }>;
    recentTransactions: TransactionWithRelations[];
  }>;

  // Investments
  getUserInvestments(userId: number): Promise<Investment[]>;
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  updateInvestment(id: number, investment: Partial<InsertInvestment>): Promise<Investment | undefined>;
  deleteInvestment(id: number): Promise<boolean>;

  // Net worth
  getUserNetWorthSnapshots(userId: number): Promise<NetWorthSnapshot[]>;
  createNetWorthSnapshot(snapshot: InsertNetWorthSnapshot): Promise<NetWorthSnapshot>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    
    // Create default categories for new user
    const defaultCategories = [
      { name: "Salary", icon: "fas fa-dollar-sign", color: "#10B981", type: "income" },
      { name: "Freelance", icon: "fas fa-laptop", color: "#059669", type: "income" },
      { name: "Food & Dining", icon: "fas fa-utensils", color: "#3B82F6", type: "expense" },
      { name: "Transportation", icon: "fas fa-car", color: "#10B981", type: "expense" },
      { name: "Shopping", icon: "fas fa-shopping-bag", color: "#8B5CF6", type: "expense" },
      { name: "Utilities", icon: "fas fa-bolt", color: "#F59E0B", type: "expense" },
      { name: "Entertainment", icon: "fas fa-film", color: "#EC4899", type: "expense" },
      { name: "Healthcare", icon: "fas fa-heart", color: "#EF4444", type: "expense" },
    ];

    await db.insert(categories).values(
      defaultCategories.map(cat => ({ ...cat, userId: user.id }))
    );

    // Create default account
    await db.insert(accounts).values({
      userId: user.id,
      name: "Main Account",
      type: "checking",
      balanceCurrent: "0",
    });

    return user;
  }

  async getUserAccounts(userId: number): Promise<Account[]> {
    return db.select().from(accounts).where(eq(accounts.userId, userId));
  }

  async createAccount(account: InsertAccount): Promise<Account> {
    const [newAccount] = await db.insert(accounts).values(account).returning();
    return newAccount;
  }

  async updateAccount(id: number, account: Partial<InsertAccount>): Promise<Account | undefined> {
    const [updated] = await db.update(accounts).set(account).where(eq(accounts.id, id)).returning();
    return updated || undefined;
  }

  async deleteAccount(id: number): Promise<boolean> {
    const result = await db.delete(accounts).where(eq(accounts.id, id));
    return result.rowCount > 0;
  }

  async getUserCategories(userId: number): Promise<Category[]> {
    return db.select().from(categories).where(eq(categories.userId, userId));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const [updated] = await db.update(categories).set(category).where(eq(categories.id, id)).returning();
    return updated || undefined;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id));
    return result.rowCount > 0;
  }

  async getUserTransactions(userId: number, limit = 50, offset = 0): Promise<TransactionWithRelations[]> {
    return db
      .select({
        id: transactions.id,
        userId: transactions.userId,
        accountId: transactions.accountId,
        categoryId: transactions.categoryId,
        amount: transactions.amount,
        type: transactions.type,
        description: transactions.description,
        date: transactions.date,
        isRecurring: transactions.isRecurring,
        recurrenceRule: transactions.recurrenceRule,
        createdAt: transactions.createdAt,
        account: accounts,
        category: categories,
      })
      .from(transactions)
      .leftJoin(accounts, eq(transactions.accountId, accounts.id))
      .leftJoin(categories, eq(transactions.categoryId, categories.id))
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.date))
      .limit(limit)
      .offset(offset);
  }

  async getTransactionsByDateRange(userId: number, startDate: string, endDate: string): Promise<TransactionWithRelations[]> {
    return db
      .select({
        id: transactions.id,
        userId: transactions.userId,
        accountId: transactions.accountId,
        categoryId: transactions.categoryId,
        amount: transactions.amount,
        type: transactions.type,
        description: transactions.description,
        date: transactions.date,
        isRecurring: transactions.isRecurring,
        recurrenceRule: transactions.recurrenceRule,
        createdAt: transactions.createdAt,
        account: accounts,
        category: categories,
      })
      .from(transactions)
      .leftJoin(accounts, eq(transactions.accountId, accounts.id))
      .leftJoin(categories, eq(transactions.categoryId, categories.id))
      .where(
        and(
          eq(transactions.userId, userId),
          gte(transactions.date, startDate),
          lte(transactions.date, endDate)
        )
      )
      .orderBy(desc(transactions.date));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values(transaction).returning();
    return newTransaction;
  }

  async updateTransaction(id: number, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined> {
    const [updated] = await db.update(transactions).set(transaction).where(eq(transactions.id, id)).returning();
    return updated || undefined;
  }

  async deleteTransaction(id: number): Promise<boolean> {
    const result = await db.delete(transactions).where(eq(transactions.id, id));
    return result.rowCount > 0;
  }

  async getDashboardData(userId: number) {
    const currentMonth = new Date().toISOString().slice(0, 7) + "-01";
    const nextMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString().slice(0, 10);

    // Get monthly totals
    const monthlyTotals = await db
      .select({
        type: transactions.type,
        total: sum(transactions.amount),
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, userId),
          gte(transactions.date, currentMonth),
          lte(transactions.date, nextMonth)
        )
      )
      .groupBy(transactions.type);

    const totalIncome = monthlyTotals.find(t => t.type === "income")?.total || "0";
    const totalExpenses = monthlyTotals.find(t => t.type === "expense")?.total || "0";
    const netCashFlow = (parseFloat(totalIncome) - parseFloat(totalExpenses)).toFixed(2);

    // Get category spending
    const categorySpending = await db
      .select({
        category: categories.name,
        amount: sum(transactions.amount),
        color: categories.color,
      })
      .from(transactions)
      .leftJoin(categories, eq(transactions.categoryId, categories.id))
      .where(
        and(
          eq(transactions.userId, userId),
          eq(transactions.type, "expense"),
          gte(transactions.date, currentMonth),
          lte(transactions.date, nextMonth)
        )
      )
      .groupBy(categories.name, categories.color)
      .orderBy(desc(sum(transactions.amount)))
      .limit(5);

    // Get recent transactions
    const recentTransactions = await this.getUserTransactions(userId, 5);

    return {
      totalIncome,
      totalExpenses,
      netCashFlow,
      categorySpending: categorySpending.map(c => ({
        category: c.category || "Unknown",
        amount: c.amount || "0",
        color: c.color || "#3B82F6",
      })),
      recentTransactions,
    };
  }

  async getUserNetWorthSnapshots(userId: number): Promise<NetWorthSnapshot[]> {
    return db
      .select()
      .from(netWorthSnapshots)
      .where(eq(netWorthSnapshots.userId, userId))
      .orderBy(desc(netWorthSnapshots.date));
  }

  async createNetWorthSnapshot(snapshot: InsertNetWorthSnapshot): Promise<NetWorthSnapshot> {
    const [newSnapshot] = await db.insert(netWorthSnapshots).values(snapshot).returning();
    return newSnapshot;
  }

  async getUserInvestments(userId: number): Promise<Investment[]> {
    return db.select().from(investments).where(eq(investments.userId, userId)).orderBy(desc(investments.createdAt));
  }

  async createInvestment(investment: InsertInvestment): Promise<Investment> {
    const [newInvestment] = await db.insert(investments).values(investment).returning();
    return newInvestment;
  }

  async updateInvestment(id: number, investment: Partial<InsertInvestment>): Promise<Investment | undefined> {
    const [updated] = await db.update(investments).set(investment).where(eq(investments.id, id)).returning();
    return updated || undefined;
  }

  async deleteInvestment(id: number): Promise<boolean> {
    const result = await db.delete(investments).where(eq(investments.id, id));
    return (result.rowCount || 0) > 0;
  }
}

export const storage = new DatabaseStorage();
