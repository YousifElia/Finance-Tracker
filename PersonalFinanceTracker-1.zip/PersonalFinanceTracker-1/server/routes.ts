import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcrypt";
import { storage } from "./storage";
import { insertUserSchema, insertAccountSchema, insertCategorySchema, insertTransactionSchema, insertInvestmentSchema, insertNetWorthSnapshotSchema } from "@shared/schema";
import { z } from "zod";

// Simple session middleware
declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);
      
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
      });

      req.session.userId = user.id;
      res.json({ user: { id: user.id, email: user.email, name: user.name } });
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      req.session.userId = user.id;
      res.json({ user: { id: user.id, email: user.email, name: user.name } });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ message: "Logged out" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      res.json({ user: { id: user.id, email: user.email, name: user.name } });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Auth middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    next();
  };

  // Dashboard routes
  app.get("/api/dashboard", requireAuth, async (req, res) => {
    try {
      const dashboardData = await storage.getDashboardData(req.session.userId!);
      res.json(dashboardData);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Account routes
  app.get("/api/accounts", requireAuth, async (req, res) => {
    try {
      const accounts = await storage.getUserAccounts(req.session.userId!);
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/accounts", requireAuth, async (req, res) => {
    try {
      const validatedData = insertAccountSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      
      const account = await storage.createAccount(validatedData);
      res.json(account);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.put("/api/accounts/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertAccountSchema.partial().parse(req.body);
      
      const account = await storage.updateAccount(id, validatedData);
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      res.json(account);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.delete("/api/accounts/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteAccount(id);
      
      if (!success) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      res.json({ message: "Account deleted" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Category routes
  app.get("/api/categories", requireAuth, async (req, res) => {
    try {
      const categories = await storage.getUserCategories(req.session.userId!);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/categories", requireAuth, async (req, res) => {
    try {
      const validatedData = insertCategorySchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      
      const category = await storage.createCategory(validatedData);
      res.json(category);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.put("/api/categories/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertCategorySchema.partial().parse(req.body);
      
      const category = await storage.updateCategory(id, validatedData);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.delete("/api/categories/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteCategory(id);
      
      if (!success) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json({ message: "Category deleted" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Transaction routes
  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;

      let transactions;
      if (startDate && endDate) {
        transactions = await storage.getTransactionsByDateRange(req.session.userId!, startDate, endDate);
      } else {
        transactions = await storage.getUserTransactions(req.session.userId!, limit, offset);
      }
      
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/transactions", requireAuth, async (req, res) => {
    try {
      const validatedData = insertTransactionSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      
      const transaction = await storage.createTransaction(validatedData);
      res.json(transaction);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.put("/api/transactions/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertTransactionSchema.partial().parse(req.body);
      
      const transaction = await storage.updateTransaction(id, validatedData);
      if (!transaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      res.json(transaction);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.delete("/api/transactions/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteTransaction(id);
      
      if (!success) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      res.json({ message: "Transaction deleted" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Net worth routes
  app.get("/api/net-worth", requireAuth, async (req, res) => {
    try {
      const snapshots = await storage.getUserNetWorthSnapshots(req.session.userId!);
      res.json(snapshots);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/net-worth", requireAuth, async (req, res) => {
    try {
      const validatedData = insertNetWorthSnapshotSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      
      const snapshot = await storage.createNetWorthSnapshot(validatedData);
      res.json(snapshot);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  // Investment routes
  app.get("/api/investments", requireAuth, async (req, res) => {
    try {
      const investments = await storage.getUserInvestments(req.session.userId!);
      res.json(investments);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/investments", requireAuth, async (req, res) => {
    try {
      const validatedData = insertInvestmentSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      
      const investment = await storage.createInvestment(validatedData);
      res.json(investment);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.put("/api/investments/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertInvestmentSchema.partial().parse(req.body);
      
      const investment = await storage.updateInvestment(id, validatedData);
      if (!investment) {
        return res.status(404).json({ message: "Investment not found" });
      }
      
      res.json(investment);
    } catch (error) {
      res.status(400).json({ message: "Invalid data" });
    }
  });

  app.delete("/api/investments/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteInvestment(id);
      
      if (!success) {
        return res.status(404).json({ message: "Investment not found" });
      }
      
      res.json({ message: "Investment deleted" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // AI Assistant route
  app.post("/api/ai/chat", requireAuth, async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Get user's financial context
      const [transactions, categories, accounts] = await Promise.all([
        storage.getUserTransactions(req.session.userId!, 20),
        storage.getUserCategories(req.session.userId!),
        storage.getUserAccounts(req.session.userId!)
      ]);

      const dashboardData = await storage.getDashboardData(req.session.userId!);
      
      // Create context for AI
      const financialContext = `
        User's Financial Summary:
        - Monthly Income: $${dashboardData.totalIncome}
        - Monthly Expenses: $${dashboardData.totalExpenses}
        - Net Cash Flow: $${dashboardData.netCashFlow}
        - Number of accounts: ${accounts.length}
        - Number of categories: ${categories.length}
        - Recent transactions: ${transactions.length}
        
        Top spending categories:
        ${dashboardData.categorySpending.map(cat => `- ${cat.category}: $${cat.amount}`).join('\n')}
      `;

      const response = await fetch('https://api.perplexity.ai/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'llama-3.1-sonar-small-128k-online',
          messages: [
            {
              role: 'system',
              content: `You are a helpful financial advisor. Use the user's financial data to provide personalized advice. Be concise and practical. Here's their financial context: ${financialContext}`
            },
            {
              role: 'user',
              content: message
            }
          ],
          max_tokens: 300,
          temperature: 0.2
        })
      });

      if (!response.ok) {
        throw new Error('AI service unavailable');
      }

      const aiResponse = await response.json();
      res.json({ 
        message: aiResponse.choices[0].message.content,
        context: financialContext
      });
    } catch (error) {
      res.status(500).json({ message: "AI service temporarily unavailable" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
